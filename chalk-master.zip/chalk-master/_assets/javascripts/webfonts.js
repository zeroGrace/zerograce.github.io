//= require webfontloader/webfontloader.js

WebFont.load({
  google: {
    families: ['Cormorant Garamond:700', 'Lato:300,400,700']
  }
});
